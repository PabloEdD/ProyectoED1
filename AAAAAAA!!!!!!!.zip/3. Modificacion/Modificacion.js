window.onload = function() {
  
    document.getElementById("Crear").style.display = "none";
    document.getElementById("Modificar").style.display = "none";
    document.getElementById("Eliminar").style.display = "none";
    document.getElementById("IDContainer").style.display = "none";
    document.getElementById("div").style.display = "none";
    var regex = /^(\d)+$/;

    $('#IDUsuari').keyup(function() {
        var valor = this.value;
        // Si el valor no esta vacio y cumple el regex...
        if ((valor.value == "") || (regex.test(valor)) == false){
          // ...oculta el div modificar, y si tiene valor correcto...
        $('#IDContainer').slideUp();
        let navAnimation1 = anime({
          targets: 'a:nth-child(1)',
          keyframes: [
                {translateY: 0},
                {translateX: 0}
              ]
        });;

        let navAnimation2 = anime({
          targets: 'a:nth-child(2)',
          keyframes: [
              {translateY: 0},
              {translateX: 0}
              ]
        });;

        let navAnimation3 = anime({
          targets: 'a:nth-child(3)',
          keyframes: [
              {translateY: 0},
              {translateX: 0}
              ]
        });;

        let navAnimation4 = anime({
          targets: 'a:nth-child(4)',
          keyframes: [
                {translateY: 0},
                {translateX: 0}
              ]
        });;

        let navAnimation5 = anime({
          targets: 'a:nth-child(5)',
          keyframes: [
                {translateY: 0},
                {translateX: 0}
              ]
        });;
        } else {
          // ...lo muestra
          $('#IDContainer').slideDown();

          let navAnimation1 = anime({
            targets: 'a:nth-child(1)',
            keyframes: [
              {translateX: 600},
              {translateY: 53}
            ]
            // translateX: [{value: 600, duration: 500}],
            // translateY: [{value: 53, duration: 1000, delay:600}]
          });;

          let navAnimation2 = anime({
            targets: 'a:nth-child(2)',
            keyframes: [
              {translateX: 459},
              {translateY: 125}
            ]
            // translateX: [{value: 459, duration: 500}],
            // translateY: [{value: 125, duration: 1000, delay:600}]
          });;

          let navAnimation3 = anime({
            targets: 'a:nth-child(3)',
            keyframes: [
              {translateX: 319},
              {translateY: 195}
            ]
            // translateX: [{value: 319, duration: 500}],
            // translateY: [{value: 195, duration: 1000, delay:600}]
          });;

          let navAnimation4 = anime({
            targets: 'a:nth-child(4)',
            keyframes: [
              {translateX: 178},
              {translateY: 265}
            ]
            // translateX: [{value: 178, duration: 500}],
            // translateY: [{value: 265, duration: 1000, delay:600}]
          });;

          let navAnimation5 = anime({
            targets: 'a:nth-child(5)',
            keyframes: [
              {translateX: 37},
              {translateY: 335}
            ]
            // keyframes: [
            //   {translateX: 37, duration: 700,
            //     height: 100,
            //     backgroundColor: "rgb(240, 105, 28)",
            //     borderColor: "rgb(255, 158, 46)",
            //     innerHTML: "Menu"
            //   },
            //   {translateY: 335, duration: 1000,
            //     height:65, duration: 600,
            //     backgroundColor: "rgb(255, 158, 46)",
            //     borderColor: "rgb(240, 105, 28)",
            //     innerHTML: "Log"
            //     }
            // ]
          });;
        }
        }).keyup(); // Se activa en KeyUp.
}

function crearUsuari() {
    document.getElementById("Titulo").innerHTML = "Crear";
    document.getElementById("Crear").style.display = "grid";
    document.getElementById("Modificar").style.display = "none";
    document.getElementById("Eliminar").style.display = "none";
    document.getElementById("IDContainer").style.display = "none";

    document.getElementById("NomCrea").value = "";
    document.getElementById("CognomsCrea").value = "";
    document.getElementById("EmailCrea").value = "";
    document.getElementById("PassCrea").value = "";
    document.getElementById("DataCrea").value = "";
    document.getElementById("TextCrea").value = "";

    let navAnimation1 = anime({
      targets: 'a:nth-child(1)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation2 = anime({
      targets: 'a:nth-child(2)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation3 = anime({
      targets: 'a:nth-child(3)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation4 = anime({
      targets: 'a:nth-child(4)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation5 = anime({
      targets: 'a:nth-child(5)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;
}

function modificarUsuari() {
    document.getElementById("Titulo").innerHTML = "Modificar";
    document.getElementById("Crear").style.display = "none";
    document.getElementById("Modificar").style.display = "grid";
    document.getElementById("Eliminar").style.display = "none";
    document.getElementById("IDContainer").style.display = "none";

    let navAnimation1 = anime({
      targets: 'a:nth-child(1)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation2 = anime({
      targets: 'a:nth-child(2)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation3 = anime({
      targets: 'a:nth-child(3)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation4 = anime({
      targets: 'a:nth-child(4)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation5 = anime({
      targets: 'a:nth-child(5)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    document.getElementById("IDUsuari").value = "";
    document.getElementById("NomModifica").value = "";
    document.getElementById("CognomsModifica").value = "";
    document.getElementById("EmailModifica").value = "";
    document.getElementById("PassModifica").value = "";
    document.getElementById("DataModifica").value = "";
    document.getElementById("PoblacioModifica").value = "";
    
    // Esto esta otra vez aqui para evitar errores al quitar y poner el IDUsuari en el apartado de Modificar.
    $("#IDUsuari").on("focusout", function() {
      $('#IDUsuari').keyup(function() {
        var valor = this.value;
        // Si el valor no esta vacio y cumple el regex...
        if ((valor.value == "") || (regex.test(valor)) == false){
          // ...oculta el div modificar, y si tiene valor correcto...
        $('#IDContainer').slideUp();

        }
        }).keyup(); // Se activa en KeyUp.
        });
}

function borrarUsuari() {
    document.getElementById("Titulo").innerHTML = "Eliminar";
    document.getElementById("Crear").style.display = "none";
    document.getElementById("Modificar").style.display = "none";
    document.getElementById("Eliminar").style.display = "grid";
    document.getElementById("IDContainer").style.display = "none";
    document.getElementsByTagName("text").value = "";

    document.getElementById("IDUsuariBorra").value = "";

    
    let navAnimation1 = anime({
      targets: 'a:nth-child(1)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation2 = anime({
      targets: 'a:nth-child(2)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation3 = anime({
      targets: 'a:nth-child(3)',
      keyframes: [
          {translateY: 0},
          {translateX: 0}
          ]
    });;

    let navAnimation4 = anime({
      targets: 'a:nth-child(4)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;

    let navAnimation5 = anime({
      targets: 'a:nth-child(5)',
      keyframes: [
            {translateY: 0},
            {translateX: 0}
          ]
    });;
  }

function mostraUsuari() {
    if (valor.value == ""){
      document.getElementById('div').style.display = "none";
    } else {
      document.getElementById('div').style.display = "grid";
    }
}
