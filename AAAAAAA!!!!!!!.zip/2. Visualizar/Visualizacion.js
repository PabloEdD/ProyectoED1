window.onload = function() {
    document.getElementById("div").style.display = "none";
}

function Visualizar() {
    document.getElementById("div").style.display = "grid";
    document.getElementsByTagName("animated-border-box").style.width = "10em";
    document.getElementsByTagName("animated-border-box-glow").style.width = "10em";
}