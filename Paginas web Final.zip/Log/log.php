<?php
// Incluir la configuración de la base de datos
include 'config.php';

// Consulta para seleccionar todos los registros de la tabla Log
$sql = "SELECT * FROM log";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Abrir o crear un archivo para escribir los registros del log
    $logFileName = 'log.txt';
    $logFile = fopen($logFileName, 'w');

    // Iterar sobre los resultados y escribir cada registro en el archivo
    while ($row = $result->fetch_assoc()) {
        $logEntry = "Fecha y hora: " . $row['fecha_hora'] . ", Tipo: " . $row['tipo'] . ", Mensaje: " . $row['mensaje'] . "\n";
        fwrite($logFile, $logEntry);
    }

    // Cerrar el archivo
    fclose($logFile);

    echo "Se ha creado el archivo $logFileName con los registros del log.";
} else {
    echo "No hay registros en la tabla Log.";
}

// Cerrar conexión
$conn->close();
?>