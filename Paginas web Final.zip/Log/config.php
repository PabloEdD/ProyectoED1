<?php
// config.php

$servername = "192.168.14.134";
$username = "root";  // Reemplaza con tu nombre de usuario de la base de datos
$password = "";  // Reemplaza con tu contraseña de la base de datos
$dbname = "Equip2PI";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>