<?php
// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexión a la base de datos
$servername = "localhost"; // Cambia esto si tu servidor no es local
$username = "root"; // Cambia esto con el usuario de tu base de datos
$password = ""; // Cambia esto con la contraseña de tu base de datos
$dbname = "Equip2PI"; // Cambia esto con el nombre de tu base de datos
// Crea la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Obtiene los datos del formulario
$email = $_POST['email'];
$passwordUser = $_POST['password'];

// Consulta SQL para verificar las credenciales
$sql = "SELECT * FROM Usuari WHERE Email = '$email' AND Contrasenya = '$passwordUser'";
$result = $conn->query($sql);

// Verifica si se encontró un usuario con las credenciales proporcionadas
if ($result->num_rows > 0) {
    echo "<script>alert('Registro exitoso');</script>";
    // Aquí podrías redirigir al usuario a otra página si lo deseas
} else {
    // Si no se encontró el usuario, muestra un mensaje de error
    echo "<script>alert('Error: Credenciales incorrectas');</script>";
}

// Cierra la conexión a la base de datos
$conn->close();
}
?>