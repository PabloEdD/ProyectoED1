<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizacion</title>
    <link rel="icon" type="image/x-icon" href="Imagenes/favicon.ico">
    <link rel="stylesheet" href="Visualizacion.css"/>
    <script type="text/javascript" src="Visualizacion.js"></script>
</head>
<body>
    <header>
        <img src="Imagenes/Logo.png" alt="Logo" width="100" height="60">
    </header>
    <nav>
        <a href="../1. Registro/Registre.html">Registro</a>
        <a href="../2. Visualizar/Visualizacion.php">Visualizar</a>
        <a href="../3. Modificacion/Modificacion.html">Modificacion</a>
        <a href="../4.BackUp/BackUp.html">BackUp</a>
        <a href="../5. Log/Log.html">Log</a>
    </nav>
    <div class="center-box">
        <div class="animated-border-box-glow"></div>
        <div class="animated-border-box">
            <form method="post" class="form" name="form" action="../../pagina.php">
                <div class="container">
                    <h2 class="titulo">Visualizacion</h2>
                    <input type="text" name="Buscador" class="text" placeholder="Buscar">
                    <input type="submit" class="button" name="button" value="Visualitzar">
                </div>
            </form>
        </div>
        <div id="div">
        </div>
    </div>
    <?php
        include("../../pagina.php");
    ?>
</body>
</html>
