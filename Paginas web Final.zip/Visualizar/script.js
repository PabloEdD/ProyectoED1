window.onload = function() {
    document.getElementById("div").style.display = "none";
}

function Visualizar() {
    document.getElementById("div").style.display = "grid";
    document.getElementById("animated-border-box").style.width = "95%";
    document.getElementById("animated-border-box-glow").style.width = "95%";
}