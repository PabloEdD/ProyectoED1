<?php
$output = shell_exec('/backupdb.sh 2>&1');
if ($output === null) {
    echo "Error ejecutando el comando.";
} else {
    echo "<pre>$output</pre>";
}
?>