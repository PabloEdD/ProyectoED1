#!/bin/bash

# Definir variables de conexión
usuario="root"
contrasena=""
nombre_base_de_datos="Equip2PI"

# Definir ruta de salida del respaldo
ruta_respaldo="/home/projectedam/htdocs_projectedam/PaginWeb/Backup/backup/Equip2PIBU.sql"

# Ejecutar mysqldump
/opt/lampp/bin/mysql -u $usuario -p $contrasena Equip2PI < $ruta_respaldo
