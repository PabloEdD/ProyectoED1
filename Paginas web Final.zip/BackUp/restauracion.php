<?php
$output = shell_exec('/restaurardb.sh 2>&1');
if ($output === null) {
    echo "Error ejecutando el comando.";
} else {
    echo "<pre>$output</pre>";
}
?>