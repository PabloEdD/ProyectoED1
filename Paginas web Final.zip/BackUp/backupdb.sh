#!/bin/bash

# Definir variables de conexión
usuario="root"
contrasena=""
nombre_base_de_datos="Equip2PI"

# Definir ruta de salida del respaldo
ruta_respaldo="/opt/lampp/htdocs/BackUp/backup/Equip2PIBU.sql"

# Ejecutar mysqldump
/opt/lampp/bin/mysqldump -u $usuario -p$contrasena $nombre_base_de_datos > $ruta_respaldo 2>&1
