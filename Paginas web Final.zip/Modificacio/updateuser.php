<?php
// updateuser.php

// Incluir la configuración de la base de datos
include 'config.php';

// ID del usuario a actualizar (obtenido del formulario)
$idUsuari = $_POST['IDUsuari'] ?? NULL;
$newNom = $_POST['Nom'] ?? NULL;
$newCognom = $_POST['Cognoms'] ?? NULL;
$newEmail = $_POST['Email'] ?? NULL;
$newContrasenya = $_POST['Pass'] ?? NULL;
$newDataNaiximent = $_POST['DataNaiximent'] ?? NULL;
$newPoblacio = $_POST['Poblacio'] ?? NULL;
$newImatgePerfil = $_FILES['Imatge']['tmp_name'] ?? NULL; // Obtener la ubicación temporal del archivo
$newRol = $_POST['Rol'] ?? NULL;

// Verificar que los datos requeridos estén presentes
if ($idUsuari !== NULL && $newNom !== NULL && $newCognom !== NULL && $newEmail !== NULL && $newContrasenya !== NULL && $newDataNaiximent !== NULL && $newPoblacio !== NULL && $newImatgePerfil !== NULL && $newRol !== NULL) {
    // Cifrar la nueva contraseña
    $newContrasenyaCifrada = password_hash($newContrasenya, PASSWORD_BCRYPT);

    // Consulta para actualizar el usuario
    $sql = "UPDATE Usuari SET Nom='$newNom', Cognom='$newCognom', Email='$newEmail', Contrasenya='$newContrasenyaCifrada', DataNaixement='$newDataNaiximent', Poblacio='$newPoblacio', ImatgePerfil='$newImatgePerfil', Rol='$newRol' WHERE IDUsuari='$idUsuari'";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario actualizado exitosamente";
    } else {
        echo "Error actualizando el usuario: " . $conn->error;
    }
} else {
    echo "Error: Datos requeridos no proporcionados";
}

// Cerrar conexión
$conn->close();
?>