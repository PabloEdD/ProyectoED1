<?php
$host="localhost";
$usuario="root";
$pass="";
$bd="Equip2PI";
$port=3306;

//conecion al servidor de BDA
$conexion=mysqli_connect($host,$usuario,$pass,$bd,$port);

//preparamos la consulta SQL
$consulta="SELECT * FROM alumne";

//ejecutamos la consulta
$resultado=mysqli_query($conexion,$consulta);

print "<table border>";
print "<tr><th> IdAlumne </th><th> Nom </th><th> Cognoms </th><th> Poblacio </th></tr>";
while ($fila=mysqli_fetch_array($resultado)) {
    $id=$fila["idalumne"];
    $nombre=$fila["nom"];
    $apellido=$fila["cognoms"];
    $poblacion=$fila["poblacio"];
    print "<tr><td>" . $id . " </td><td> " . $nombre . " </td><td> " . $apellido . "</td><td> " . $poblacion . "</td></tr>";
}
print "</table>";

//cerramos la conexion
mysqli_close($conexion);

?>