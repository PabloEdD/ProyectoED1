<?php
// deleteuser.php

// Incluir la configuración de la base de datos
include 'config.php';

// ID del usuario a eliminar (obtenido del formulario)
$idUsuari = $_POST['idUsuari'] ?? NULL;

if ($idUsuari !== NULL) {
    // Consulta para eliminar el usuario
    $sql = "DELETE FROM Usuari WHERE IDUsuari='$idUsuari'";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario eliminado exitosamente";
    } else {
        echo "Error eliminando el usuario: " . $conn->error;
    }
} else {
    echo "Error: ID de usuario no proporcionado";
}

// Cerrar conexión
$conn->close();
?>